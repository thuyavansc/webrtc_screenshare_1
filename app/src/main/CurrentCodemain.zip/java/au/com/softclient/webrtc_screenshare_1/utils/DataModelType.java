package au.com.softclient.webrtc_screenshare_1.utils;

public enum DataModelType {
    SignIn,
    StartStreaming,
    EndCall,
    Offer,
    Answer,
    IceCandidates
}